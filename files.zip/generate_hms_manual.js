const fs = require('fs');
const https = require('https');
const { JSDOM } = require('jsdom');
const PDFDocument = require('pdfkit');

// Read the HMS codes mapping
const urlToCodesPath = process.argv[2] || './url_to_codes_mapping.json';
const outputPath = process.argv[3] || './P1_Series_HMS_Manual.pdf';

const urlToCodes = JSON.parse(fs.readFileSync(urlToCodesPath, 'utf-8'));

// Helper to fetch a URL
function fetchURL(url) {
  return new Promise((resolve, reject) => {
    https.get(url, (res) => {
      let data = '';
      res.on('data', (chunk) => data += chunk);
      res.on('end', () => resolve(data));
    }).on('error', reject);
  });
}

// Extract article content from HTML
function extractArticleContent(html) {
  const dom = new JSDOM(html);
  const doc = dom.window.document;
  
  // Find the main article content
  // Common selectors for wiki content
  const mainContent = doc.querySelector('article') || 
                     doc.querySelector('.content') ||
                     doc.querySelector('main') ||
                     doc.querySelector('.article-content') ||
                     doc.querySelector('#content');
  
  if (!mainContent) {
    console.warn('Could not find main content area');
    return null;
  }
  
  // Remove unwanted elements
  const unwantedSelectors = [
    'nav',
    'header',
    'footer',
    '.navigation',
    '.sidebar',
    '.toc',
    '.table-of-contents',
    '.breadcrumb',
    '.edit-button',
    '.toolbar',
    '.menu',
    '.advertisement',
    'script',
    'style',
    'iframe',
    '.share-buttons',
    '.social-media'
  ];
  
  unwantedSelectors.forEach(selector => {
    mainContent.querySelectorAll(selector).forEach(el => el.remove());
  });
  
  // Extract the title
  const title = doc.querySelector('h1')?.textContent?.trim() || 'Unknown Error Code';
  
  // Extract text content with basic structure
  const content = {
    title,
    sections: []
  };
  
  // Process headings and paragraphs
  const elements = mainContent.querySelectorAll('h1, h2, h3, h4, p, ul, ol, pre, code, table');
  let currentSection = null;
  
  elements.forEach(el => {
    const tagName = el.tagName.toLowerCase();
    
    if (tagName.match(/^h[1-4]$/)) {
      if (currentSection) {
        content.sections.push(currentSection);
      }
      currentSection = {
        type: 'heading',
        level: parseInt(tagName[1]),
        text: el.textContent.trim()
      };
    } else if (tagName === 'p') {
      const text = el.textContent.trim();
      if (text) {
        if (!currentSection) {
          currentSection = { type: 'paragraph', text: '' };
        }
        if (currentSection.type === 'heading') {
          content.sections.push(currentSection);
          currentSection = { type: 'paragraph', text };
        } else {
          currentSection.text += '\n\n' + text;
        }
      }
    } else if (tagName === 'ul' || tagName === 'ol') {
      if (currentSection && currentSection.type !== 'heading') {
        content.sections.push(currentSection);
      }
      const items = Array.from(el.querySelectorAll('li')).map(li => li.textContent.trim());
      content.sections.push({
        type: 'list',
        ordered: tagName === 'ol',
        items
      });
      currentSection = null;
    } else if (tagName === 'pre' || tagName === 'code') {
      if (currentSection && currentSection.type !== 'heading') {
        content.sections.push(currentSection);
      }
      content.sections.push({
        type: 'code',
        text: el.textContent.trim()
      });
      currentSection = null;
    }
  });
  
  if (currentSection) {
    content.sections.push(currentSection);
  }
  
  return content;
}

// Create PDF
async function generatePDF(articles, outputPath) {
  const doc = new PDFDocument({
    size: 'LETTER',
    margins: { top: 50, bottom: 50, left: 50, right: 50 },
    bufferPages: true
  });
  
  const stream = fs.createWriteStream(outputPath);
  doc.pipe(stream);
  
  // Title page
  doc.fontSize(24).font('Helvetica-Bold')
     .text('Bambu Lab P1 Series', { align: 'center' });
  doc.moveDown(0.5);
  doc.fontSize(20)
     .text('HMS Error Code Manual', { align: 'center' });
  doc.moveDown(0.5);
  doc.fontSize(12).font('Helvetica')
     .text('Health Management System (HMS) Troubleshooting Guide', { align: 'center' });
  doc.moveDown(1);
  doc.fontSize(10)
     .text(`Generated: ${new Date().toLocaleDateString()}`, { align: 'center' });
  
  doc.addPage();
  
  // Table of contents
  doc.fontSize(18).font('Helvetica-Bold')
     .text('Table of Contents', { underline: true });
  doc.moveDown(1);
  
  doc.fontSize(10).font('Helvetica');
  articles.forEach((article, index) => {
    const codes = article.codes.join(', ');
    doc.text(`${index + 1}. ${codes}`, { 
      continued: true,
      link: `#page_${index + 1}`
    });
    doc.text(` ............... Page ${index + 1}`);
  });
  
  // Content pages
  articles.forEach((article, index) => {
    doc.addPage();
    
    // Add bookmark for navigation
    doc.addNamedDestination(`page_${index + 1}`);
    
    // Error codes header
    doc.fontSize(16).font('Helvetica-Bold')
       .fillColor('#000000')
       .text(`Error Code${article.codes.length > 1 ? 's' : ''}: ${article.codes.join(', ')}`);
    doc.moveDown(0.5);
    
    // Horizontal line
    doc.moveTo(50, doc.y).lineTo(562, doc.y).stroke('#CCCCCC');
    doc.moveDown(0.5);
    
    if (!article.content) {
      doc.fontSize(10).font('Helvetica')
         .fillColor('#000000')
         .text('Content not available');
      return;
    }
    
    // Render sections
    article.content.sections.forEach(section => {
      // Check if we need a new page
      if (doc.y > 700) {
        doc.addPage();
      }
      
      switch (section.type) {
        case 'heading':
          const fontSize = 16 - (section.level * 2);
          doc.fontSize(fontSize).font('Helvetica-Bold')
             .fillColor('#000000')
             .text(section.text);
          doc.moveDown(0.5);
          break;
          
        case 'paragraph':
          doc.fontSize(10).font('Helvetica')
             .fillColor('#000000')
             .text(section.text, {
               align: 'left',
               lineGap: 2
             });
          doc.moveDown(0.5);
          break;
          
        case 'list':
          section.items.forEach((item, idx) => {
            const bullet = section.ordered ? `${idx + 1}.` : '•';
            doc.fontSize(10).font('Helvetica')
               .fillColor('#000000')
               .text(`  ${bullet} ${item}`, {
                 indent: 20,
                 lineGap: 2
               });
          });
          doc.moveDown(0.5);
          break;
          
        case 'code':
          doc.fontSize(9).font('Courier')
             .fillColor('#000000')
             .rect(doc.x, doc.y, 500, doc.heightOfString(section.text) + 10)
             .fillAndStroke('#F5F5F5', '#CCCCCC')
             .fillColor('#000000')
             .text(section.text, doc.x + 5, doc.y + 5);
          doc.moveDown(0.5);
          break;
      }
    });
    
    // Footer with page number
    const pageCount = doc.bufferedPageRange().count;
    for (let i = 0; i < pageCount; i++) {
      doc.switchToPage(i);
      doc.fontSize(8).font('Helvetica')
         .fillColor('#666666')
         .text(`Page ${i + 1} of ${pageCount}`, 50, 750, { 
           align: 'center',
           width: 512
         });
    }
  });
  
  doc.end();
  
  return new Promise((resolve, reject) => {
    stream.on('finish', resolve);
    stream.on('error', reject);
  });
}

// Main execution
async function main() {
  console.log('Starting HMS Manual Generation...');
  console.log(`Total unique URLs to fetch: ${Object.keys(urlToCodes).length}`);
  
  const articles = [];
  let processed = 0;
  
  for (const [url, codes] of Object.entries(urlToCodes)) {
    processed++;
    console.log(`[${processed}/${Object.keys(urlToCodes).length}] Fetching: ${url}`);
    
    try {
      const html = await fetchURL(url);
      const content = extractArticleContent(html);
      
      articles.push({
        url,
        codes,
        content
      });
      
      // Rate limiting - be nice to the server
      await new Promise(resolve => setTimeout(resolve, 500));
    } catch (error) {
      console.error(`Error fetching ${url}:`, error.message);
      articles.push({
        url,
        codes,
        content: null
      });
    }
  }
  
  console.log('\nGenerating PDF...');
  await generatePDF(articles, outputPath);
  
  console.log(`\nPDF generated successfully: ${outputPath}`);
  console.log(`Total pages: ${articles.length + 2}`); // +2 for title and TOC
}

main().catch(console.error);
